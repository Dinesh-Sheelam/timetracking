<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/functions.php';
checkAdminLogin();

// Get statistics using prepared statements
try {
    // Total Employees
    $stmt = $db->prepare("SELECT COUNT(*) as count FROM employees");
    $stmt->execute();
    $result = $stmt->get_result();
    $totalEmployees = $result->fetch_assoc()['count'];

    // Today's Entries
    $stmt = $db->prepare("SELECT COUNT(*) as count FROM time_entries WHERE DATE(created_at) = CURDATE()");
    $stmt->execute();
    $result = $stmt->get_result();
    $todayEntries = $result->fetch_assoc()['count'];

    // Pending Requests
    $stmt = $db->prepare("SELECT COUNT(*) as count FROM time_entries WHERE status = 'pending'");
    $stmt->execute();
    $result = $stmt->get_result();
    $pendingRequests = $result->fetch_assoc()['count'];
} catch (Exception $e) {
    // Set default values if queries fail
    $totalEmployees = 0;
    $todayEntries = 0;
    $pendingRequests = 0;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - TimeTrack</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .dashboard-header {
            background-color: #fff;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            padding: 1rem 0;
            margin-bottom: 2rem;
        }
        .card {
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            border-radius: 8px;
            margin-bottom: 1rem;
            transition: transform 0.2s;
        }
        .card:hover {
            transform: translateY(-2px);
        }
        .statistics-card h2 {
            color: #0d6efd;
            font-size: 2.5rem;
            margin: 0;
        }
        .nav-card {
            height: 100%;
        }
        .nav-card .btn {
            margin-top: auto;
        }
    </style>
</head>
<body class="bg-light">
    <div class="dashboard-header">
        <div class="container">
            <div class="d-flex justify-content-between align-items-center">
                <h2 class="mb-0">Admin Dashboard</h2>
                <div>
                    <span class="me-3">Welcome, <?php echo htmlspecialchars($_SESSION['admin_name']); ?></span>
                    <a href="logout.php" class="btn btn-outline-danger">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <!-- Statistics Cards -->
        <div class="row mb-4">
            <div class="col-md-4">
                <div class="card statistics-card">
                    <div class="card-body">
                        <h5 class="card-title text-muted mb-3">Total Employees</h5>
                        <h2 class="card-text"><?php echo $totalEmployees; ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card statistics-card">
                    <div class="card-body">
                        <h5 class="card-title text-muted mb-3">Today's Entries</h5>
                        <h2 class="card-text"><?php echo $todayEntries; ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card statistics-card">
                    <div class="card-body">
                        <h5 class="card-title text-muted mb-3">Pending Requests</h5>
                        <h2 class="card-text"><?php echo $pendingRequests; ?></h2>
                    </div>
                </div>
            </div>
        </div>

        <!-- Navigation Cards -->
        <div class="row">
            <div class="col-md-4 mb-4">
                <div class="card nav-card">
                    <div class="card-body d-flex flex-column">
                        <h5 class="card-title">View Employees</h5>
                        <p class="card-text text-muted">Manage employee records and information</p>
                        <a href="view_employees.php" class="btn btn-primary mt-auto">View Employees</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="card nav-card">
                    <div class="card-body d-flex flex-column">
                        <h5 class="card-title">Time Sheets</h5>
                        <p class="card-text text-muted">View and manage employee time sheets</p>
                        <a href="view_timesheets.php" class="btn btn-primary mt-auto">View Time Sheets</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="card nav-card">
                    <div class="card-body d-flex flex-column">
                        <h5 class="card-title">Manual Entry Requests</h5>
                        <p class="card-text text-muted">Review and approve manual time entry requests</p>
                        <a href="manage_requests.php" class="btn btn-primary mt-auto">View Requests</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>