<?php
require_once '../includes/config.php';

// Clear all session data
session_start();
session_destroy();

// Redirect to admin login page
header('Location: index.php');
exit();
?>